const bar = document.querySelector('.bar_sm')
const menu = document.querySelector(".menu_sm")

bar.onclick = function() {
    menu.classList.toggle('active')
    console.log('ishlad')
}



console.log(menu)


const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});